import java.util.*;
import java.lang.*;
class array{
public static void main(String args[]){
int ar1[][]=new int[2][3];
		
		System.out.println("Enter the elements for 2 X 3  array : ");
		int i=0;
		do
		{
                 int j=0;
			do
			{
				ar1[i][j]=sc.nextInt();
                        j++;
			}while(j<3);
                      i++;
		}while(i<2);
		System.out.println("Elements of array : ");
             int i=0;
		do
		{   
                  int j=0;
			do
			{
				System.out.print(ar1[i][j]+" ");
                        j++;
			}while(j<3);
			System.out.println();
			i++;
		}while(i<2);
		System.out.println("Address of Array : ");
		
