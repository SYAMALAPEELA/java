import java.util.*;
import java.lang.*;
class array{
public static void main(String args[]){
int ar1[][]=new int[2][3];
		
		System.out.println("Enter the elements for 2 X 3  array : ");
		int i=0;
		while(i<2)
		{
                 int j=0;
			while(j<3)
			{
				ar1[i][j]=sc.nextInt();
                        j++;
			}
                      i++;
		}
		System.out.println("Elements of array : ");
             int i=0;
		while(i<2)
		{   
                  int j=0;
			while(j<3)
			{
				System.out.print(ar1[i][j]+" ");
                        j++;
			}
			System.out.println();
			i++;
		}
		System.out.println("Address of Array : ");
		
