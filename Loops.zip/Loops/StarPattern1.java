package Loops;

public class StarPattern1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=1;i<=5;i++)
		{
			for(int j=1;j<=5;j++)
			{
				if(i==1) {
				System.out.print(" "+i);}
				else if(j==1) {
					System.out.print(" "+j);
				}
				else {
					if(i==j)
					{
						for(int s=1;s<j-1;s++)
						System.out.print("  ");
						System.out.print(" "+j);
					}
				}
			}
				System.out.println();
			
		}

	}

}
