package Loops;

public class Print100To1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=100;
		while(i>=1) {
			System.out.println(i);
			i--;
		}

	}

}
