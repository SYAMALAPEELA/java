package Loops;

import java.util.Scanner;

public class StarPattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number");
		int n=sc.nextInt();
		for(int i=1;i<=(2*n-1);i++)
		{
			for(int j=i;j<=(2*n-1);j++)
			{
				System.out.print("*");
			}
			System.out.println();
		}
		for(int i=1;i<=n;i++)
		{
			for(int s=n-1;s>=i;s--) {
				System.out.print(" ");
			}
			for(int j=i;j<=2*i-1;j++)
			{
				System.out.print("*");
				
			}
			System.out.println();

		}

	}

}
