package Loops;

import java.util.Scanner;

public class SumOfCubes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
	     System.out.println("enter a number");
	    
	     int num=sc.nextInt();
	     int start=1,sum=0,temp;
	     while(start<=num)
	     {
	    	 temp=start*start*start;
	    	 sum=sum+temp;
	    	 start++;
	     }
System.out.println("cube sum is:"+sum);
	}

}
