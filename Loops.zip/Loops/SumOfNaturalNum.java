package Loops;

import java.util.Scanner;

public class SumOfNaturalNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
	     System.out.println("enter the number:");
	    
	     int num=sc.nextInt();
	     int start=1,sum=0;
	     while(start<=num)
	     {
	    	 sum=sum+start;
	    	 start++;
	     }
	System.out.println((num*(num+1)/2));     
System.out.println("sum is "+sum);
sc.close();
	}

}
