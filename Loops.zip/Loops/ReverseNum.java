package Loops;

import java.util.Scanner;

public class ReverseNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
	     System.out.println("enter the number:");
	    
	     int num=sc.nextInt();
	     int reverse=0,i=0;
	     while(num!=0)
	     {
	    	 int rem=num%10;
	    	 reverse=reverse*10+rem;
	    			 num=num/10;
	         
	     }   
System.out.println("sum is "+reverse);
	}

}
