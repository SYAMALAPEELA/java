package Loops;

public class PrintATOZ {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char start='A';
		while(start<='Z')
		
		{
			System.out.println(start++);
		}

	}

}
