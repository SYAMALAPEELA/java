package Loops;
import java.util.*;
import java.io.*;
import java.lang.*;
public class HackerRank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	


		



		        Scanner sc = new Scanner(System.in);
		        int t=sc.nextInt();

		        for(int i=0;i<t;i++)
		        {

		            try
		            {
		                long x=sc.nextLong();
		                System.out.println(x+" can be fitted in:");
		                if(x>=-128 && x<=127)System.out.println("* byte");
		                //Complete the code
		                if(x>=(-(Math.pow(2,15)+1))&& x<=(Math.pow(2,15))){System.out.println("* short");}
		                 if(x>=(-(Math.pow(2,31)+1))&& x<=(
		                     Math.pow(2,31))){System.out.println("* int");}
		                  if(x>=-(Math.pow(2,61)+1)&& x<=(Math.pow(2,61))){System.out.println("* long");}
		            
		                  // System.out.print("vvvvvvvvvvvv"+ -(Math.pow(2,31)+1))   ;
		                  }
		                
		            
		            catch(Exception e)
		            {
		                System.out.println(sc.next()+" can't be fitted anywhere.");
		            }

		        }
		    }
		


	}


