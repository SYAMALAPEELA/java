package Loops;

public class StarPattern2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=1;i<=3;i++) {
			for(int s=3;s>i;s--) {
				System.out.print(" ");
				
			}
			for(int j=1;j<=i;j++)
			{
				System.out.print(j);
			}
			for(int k=i;k>=2;k--)
			{
				System.out.print(k-1);
			}
			System.out.println();
		}

	}

}
