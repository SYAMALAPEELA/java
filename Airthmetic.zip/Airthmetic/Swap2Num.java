package Airthmetic;

public class Swap2Num {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		{
			int a=10,b=30;
            int c=a;
            a=b;
            b=c;
            System.out.println(a+" "+b);
            int x=5,y=10;
            x=x+y;
            y=x-y;
            x=x-y;
            System.out.println(x+" "+y);
            
            }

	}

}
