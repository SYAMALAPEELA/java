package Airthmetic;

public class IncreDec {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10,b=-5,c=100;
		
		System.out.println("output"+((a++) + (--b)-c+a+(++c)+(b--)));
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(++a);
		System.out.println(a++);
		System.out.println(--a);
		System.out.println(a--);
		System.out.println(a);

	}

}
