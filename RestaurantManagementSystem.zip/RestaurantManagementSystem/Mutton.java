package RestaurantManagementSystem;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class Mutton 
{
	//Storing  and displaying List items - Set format
	Set<ItemList> muttonList=new TreeSet<ItemList>();
	Mutton()
	{
		
		
		//Make a List of Mutton items
		muttonList.add(new ItemList(301,"Mutton curry",1,300));
		muttonList.add(new ItemList(302,"Mutton fry",1,300));
		muttonList.add(new ItemList(303,"Mutton Kheema",1,300));
		
	}	
		//display 
		void display() 
		{
			muttonList.stream().forEach(System.out::println);
		}

}
