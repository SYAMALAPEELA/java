package RestaurantManagementSystem;

import java.util.Scanner;

public class Page2 implements MainInterface1,MainInterface2
{
	int item;
	ManualException me=new ManualException(toString());
	Scanner sc=new Scanner(System.in);
		
		
		
		

	//common display code for both the parcel and dining
	public void parcel() //throws ManualException                             
		{
		 do
		 {
			
			System.out.println("food list:");
			System.out.println("1:Biryani");
			System.out.println("2:Meals");
			System.out.println("3:Chicken");
			System.out.println("4:Mutton");
			System.out.println("0:for exit");
			System.out.println("enter food item-type");
			
			item=sc.nextInt();
			
			
			
			if(item==1)
			{
				Biryani biryani=new Biryani();
				biryani.display();
				SelectItem S=new SelectItem();
				Catalogue c=new Catalogue();
				//c.display();
			}
			if(item==2)
			{
				Meals meals=new Meals();
				meals.display();
				//SelectItem();
			}
			if(item==3) 
			{
				Chicken chicken=new Chicken();
				chicken.display();
				//SelectItem();
			}
			if(item==4)
			{
				Mutton mutton=new Mutton();
				mutton.display();
				//SelectItem();
			}
			}
			while(item!=0);	
		//billing();
	}

	
	public void dining() //throws ManualException 
	{
		parcel();
		//reserveTable();
		//billing();
		
		
		
	}
	
//sc.close();	
}