package RestaurantManagementSystem;

import java.util.Scanner;

public class Page2 implements MainInterface1,MainInterface2
{
	int item;
	Scanner sc=new Scanner(System.in);
		
		

	//common display code for both the parcel and dining
	public void parcel()                            
		{
		 do
		 {
			
			System.out.println("food list:");
			System.out.println("1:Biryani");
			System.out.println("2:Meals");
			System.out.println("3:Chicken");
			System.out.println("4:Mutton");
			System.out.println("0:for exit");
			System.out.println("enter food item-type");
			
			item=sc.nextInt();
			
			
			
			switch(item)
			{
			case 1:
				Biryani biryani=new Biryani();
				biryani.display();
				SelectItem S=new SelectItem();
				Catalogue c=new Catalogue();
				//c.display();
				break;
			
			case 2:
				Meals meals=new Meals();
				meals.display();
				//SelectItem();
			    break;
			case 3:
				Chicken chicken=new Chicken();
				chicken.display();
				//SelectItem();
			
			case 4:
				Mutton mutton=new Mutton();
				mutton.display();
				//SelectItem();
			    break;
			default:
				throw new IllegalArgumentException("Unknown option"+item);
			}
			}while(item!=0);	
		//billing();
	}

	
	public void dining()
	{
		parcel();
		//reserveTable();
		//billing();
		
		
		
	}
	
//sc.close();	
}