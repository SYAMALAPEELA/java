package RestaurantManagementSystem;
import java.lang.*;

public class ItemList implements Comparable<ItemList>
{
	private int itemId;
	private String itemName;
	int itemCount;
	private int itemCost;
	public ItemList(int itemId, String itemName,int itemCount,int itemCost) 
	{
		super();
		this.setItemId(itemId);
		this.setItemName(itemName);
		this.setItemCount(itemCount);
		this.setItemCost(itemCount*itemCost);
	}
	public int getItemId()
	{
		return itemId;
	}
	public String getItemName()
	{
		return itemName;
	}
	public int getItemCount()
	{
		return itemCount;
	}
	public int getItemCost()
	{
		return itemCost;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public void setItemCount(int itemCount) {
		this.itemCount= itemCount;
	}
	public void setItemCost(int itemCost) {
		this.itemCost = itemCost;
	}
	
	public String toString()
	{
		return "id:"+getItemId()+",   item:"+getItemName()+",   Count:"+getItemCount()+",  Cost:"+getItemCost()+")";
	}
	public int compareTo(ItemList i)
	{
		if(getItemId()>i.getItemId())
		{
			return 1;
		}
		else if(getItemId()>i.getItemId())
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}



	
}
