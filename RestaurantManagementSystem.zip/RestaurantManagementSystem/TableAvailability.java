package RestaurantManagementSystem;

public class TableAvailability {

}
