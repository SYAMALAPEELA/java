package RestaurantManagementSystem;


public class TableAvailability 
{
	Tables t[]=Tables.values();
	TableAvailability()
	{
	
	
	for(Tables tab:t)
	{
		if(tab.getStatus().equals("ACTIVE"))
		{
			tab.setStatus("RESERVED");
			System.out.println(tab);
			break;
		}
	
	}
	}
}