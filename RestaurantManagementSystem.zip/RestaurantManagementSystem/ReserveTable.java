package RestaurantManagementSystem;

public class ReserveTable 
{
	synchronized void isAvailable()
	{
		if(free) 
		{
			Tables tables=Tables.values
		}
		else
		{
			
		}
		
	}
}
class MyThread1 extends Thread
{
	Table t;
	MyThread1()
	{
		this.t=t;
	
	}
	public void run()
	{
	 t.printTable()
	}
}
