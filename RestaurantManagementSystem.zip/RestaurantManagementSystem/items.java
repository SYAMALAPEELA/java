package RestaurantManagementSystem;

public enum items {

}
