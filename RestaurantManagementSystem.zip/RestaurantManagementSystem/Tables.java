package RestaurantManagementSystem;

public enum Tables 
{
	 Table1,Table2,Table3,Table4,Table5,Table6,Table7,Table8,Table9,Table10;
}
