package RestaurantManagementSystem;

import java.util.Arrays;
import java.util.Optional;

public enum Tables 
{
	 TABLE1("ACTIVE"),TABLE2("ACTIVE"),TABLE3("ACTIVE"),TABLE4("ACTIVE"),TABLE5("ACTIVE"),TABLE6("ACTIVE"),TABLE7("ACTIVE"),TABLE8("ACTIVE"),TABLE9("ACTIVE"),TABLE10("ACTIVE");
	String status;
	Tables(String TableStatus )
	{
		setStatus(TableStatus);
		
	}
	public void setStatus(String status)
	{
		this.status=status;
	}
	public String getStatus()
	{
		return status;
	}
}
