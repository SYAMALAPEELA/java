package RestaurantManagementSystem;

class ManualException extends Exception
{
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		ManualException(String str)
		{
			super(str);
		}

}

