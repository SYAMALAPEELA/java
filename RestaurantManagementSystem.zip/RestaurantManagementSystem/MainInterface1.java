package RestaurantManagementSystem;

interface MainInterface1 
{
	void parcel(); //throws ManualException; 
}
interface MainInterface2
{
	void dining(); //throws ManualException;
}
