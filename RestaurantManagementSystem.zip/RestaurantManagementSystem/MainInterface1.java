package RestaurantManagementSystem;

interface MainInterface1 
{
	void parcel(); 
}
interface MainInterface2
{
	void dining(); 
}
