package RestaurantManagementSystem;

import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class Parcel implements MainInterface1
{
	static int item;
	Scanner sc=new Scanner(System.in);

	//common display code for both the parcel and dining
	    public void parcel() 
	    {
		 do
		 {
			
			System.out.println("food list:");
			System.out.println("1:Biryani");
			System.out.println("2:Meals");
			System.out.println("3:Chicken");
			System.out.println("4:Mutton");
			System.out.println("0:for exit");
			System.out.println("enter food item-type");
			
			item=sc.nextInt();
			
			
			
			switch(item)
			{
			case 0:
				//new Billing();
				break;
			case 1:
				Biryani biryani=new Biryani();
				biryani.display();
				//new SelectItem();
				break;
			case 2:
				Meals meals=new Meals();
				meals.display();
				//new SelectItem();
			    break;
			case 3:
				Chicken chicken=new Chicken();
				chicken.display();
				//new SelectItem();
				break;
			case 4:
				Mutton mutton=new Mutton();
				mutton.display();
				//new SelectItem();
			    break;
			default:
				throw new IllegalArgumentException(" ;page 2 Unknown option"+item);
			}
			new Billing();
			}while(item!=0);	
	
	}

	
	
	
//sc.close();	
}