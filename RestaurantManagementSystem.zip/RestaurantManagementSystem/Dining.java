package RestaurantManagementSystem;

public class Dining extends Parcel implements MainInterface2 
{
	public void dining()
	{
		
		new TableAvailability();
		parcel();
		
	}
}
