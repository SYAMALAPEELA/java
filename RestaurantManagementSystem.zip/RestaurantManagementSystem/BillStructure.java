package RestaurantManagementSystem;

public class BillStructure 
{
	
}
