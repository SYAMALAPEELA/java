package RestaurantManagementSystem;

public class BillStructure 
{
		public Billing billing(String billType)
		{
			if (billType == null || billType.isEmpty())
				return null;
			switch (billType) {
			case "parcel":
				return new x();
			case "Dining":
				return new x();
				
			default:
				throw new IllegalArgumentException("Unknown channel "+billType);
			}
		}
	}

}
