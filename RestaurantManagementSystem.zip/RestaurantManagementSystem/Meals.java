package RestaurantManagementSystem;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class Meals 
{
	//Storing  and displaying List items - Set format
	Set<ItemList> mealsList=new TreeSet<ItemList>();
	Meals()
	{
		
		//Make a List of Mutton items
		mealsList.add(new ItemList(201,"Veg Meal",1,100));
		mealsList.add(new ItemList(202,"Chicken Meal",1,200));
	}
	
	//display 
	void display() 
	{
		mealsList.stream().forEach(System.out::println);
	}
}
