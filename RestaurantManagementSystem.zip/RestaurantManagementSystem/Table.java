package RestaurantManagementSystem;
import java.lang.*;
public class Table 
{    
	Tables table[]=Tables.values();
		 
		//String[] tableStatus={"ACTIVE","RESERVED" };
		for(Tables t:tables) 
		{
			t.
		}
		
		

}
