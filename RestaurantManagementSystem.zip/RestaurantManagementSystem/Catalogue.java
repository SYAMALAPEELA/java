package RestaurantManagementSystem;

import java.util.ArrayList;
import java.util.Set;
import java.util.TreeSet;

public class Catalogue 
{
	Set<ItemList> mergedList=new TreeSet<>();
	Catalogue()
	{
		
		//adding list2 elements in list1
		mergedList.addAll(new Biryani().biryaniList);
		mergedList.addAll(new Meals().mealsList);
		mergedList.addAll(new Chicken().chickenList);
		mergedList.addAll(new Mutton().muttonList);
	}
		void display() 
		{
			mergedList.stream().forEach(System.out::println);
		}
}
