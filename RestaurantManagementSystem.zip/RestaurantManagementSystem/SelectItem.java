package RestaurantManagementSystem;

import java.util.*;
import java.util.stream.Collectors;

public class SelectItem 
{
	Scanner sc=new Scanner(System.in);
	SelectItem()
	{
		Set<ItemList> BillingItem=new TreeSet<>();
		
		System.out.println("enter Id for which food you want");
		Integer itemId=sc.nextInt();
	    
		System.out.println("enter how many packets do you want");
		int itemCount=sc.nextInt();
		Catalogue catalog=new Catalogue();
		ItemList x = catalog.mergedList.stream()
				  .filter(I -> itemId.equals(I.getItemId()))
				  .findAny()
				  .orElse(null);
		List<ItemList> selectCount=catalog.mergedList.stream().filter(i->itemId.equals(i.getItemId())).filter(i->i.itemCount.get(itemCount)).collect(Collectors.toList());
		/* ItemList i;
		((ItemList) i).itemId();
		catalog.mergedList.itemId i1=itemId1;
		//ItemList iL=new ItemList(0, null, 0, 0);
		//
		//List<ItemList> selectedItem=catalog.stream().filter(i->i.itemId == itemId).map(c->c.itemCost).collect(Collectors.toList());
		catalog.mergedList.set(catalog.mergedList.itemId.contains(I));
		if(catalog.mergedList.contains(itemId1))
		{
			((ItemList) catalog.mergedList).itemId.indexOf(I);
		}
		for(ItemList c:catalog.mergedList )
		{
			if(c.itemId==I) 
			{
				c.itemId(contains(itemId1));
				c.itemCount=itemCount;
			
				BillingItem.add(new ItemList(c.itemId,c.itemName,c.itemCount,c.itemCost));
			}
		}
		BillingItem.stream().forEach(System.out::println);*/
	}
}
