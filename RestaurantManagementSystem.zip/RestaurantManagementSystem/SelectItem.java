package RestaurantManagementSystem;

import java.util.*;
import java.util.stream.Collectors;

public class SelectItem 
{
	Scanner sc=new Scanner(System.in);
	Set<ItemList> billingItem=new TreeSet<>();
	//selected items by customer
	SelectItem()
	{
		
		
		System.out.println("enter Id for which food you want");
		int itemId=sc.nextInt();
	    
		System.out.println("enter how many packets do you want");
		int itemCount=sc.nextInt();
		Catalogue catalog=new Catalogue();
		/*List<Integer> L = catalog.mergedList.stream()
				  .filter(I -> itemId.equals(I.getItemId()))
				  .findAny()
				  .orElse(null).map(x->x.setItemCount(itemCount)).collect(Collectors.toList());*/
		for(ItemList c:catalog.mergedList )
		{
			if(c.getItemId()==itemId) 
			{
				c.setItemCount(itemCount);
			
				billingItem.add(new ItemList(c.getItemId(),c.getItemName(),c.getItemCount(),c.getItemCost()));
			}
		}
		//billingItem.stream().forEach(System.out::println);
	}
}
