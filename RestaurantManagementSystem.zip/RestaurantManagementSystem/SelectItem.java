package RestaurantManagementSystem;

import java.util.*;
import java.util.stream.Collectors;

public class SelectItem 
{
	private static SelectItem SelectItem=new SelectItem();
	Set<ItemList> billingItem=new TreeSet<>();
	private SelectItem()
	{
		
	}
	public static SelectItem getSelectItem()
	{
		return SelectItem;
	}
	
	
}
