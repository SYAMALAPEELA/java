package RestaurantManagementSystem;
import java.util.*;

public class Biryani 
{
	Set<ItemList> biryaniList=new TreeSet<ItemList>();

	Biryani()
	{
		
		
		//Make a List of Biryani items
		biryaniList.add(new ItemList(101,"Chicken Biryani",1,200));
		biryaniList.add(new ItemList(102,"Mutton Biryani",1,300));
		biryaniList.add(new ItemList(103,"prawn Biryani",1,250));
		biryaniList.add(new ItemList(104,"Dum Biryani",1,350));
		
	 }
	//display 
	void display() 
	{
		biryaniList.stream().forEach(System.out::println);
	}
	
}
