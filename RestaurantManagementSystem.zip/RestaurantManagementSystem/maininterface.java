package RestaurantManagementSystem;

public interface maininterface
{
		//for parcel food 
		  
}
interface mainInterface2
{
	   //for dining food
	   void dining();
}

