package RestaurantManagementSystem;

import java.util.Scanner;

public class HomePage //choose option for parcel and dining
{
 static int  parcelOrDining;
	public static void main(String[] args) 
	{
		
	
			System.out.println("press\n\t1:parcel\n\t2.dining\n\t3:catalogue\n\t0:exit");
			Scanner sc=new Scanner(System.in);
			 parcelOrDining=sc.nextInt();
			check(parcelOrDining);
	}
		
	static void check(int parcelOrDining) 
	{
			Dining ob=new Dining();
			do
			{
				
			switch(parcelOrDining)
			{
			case 1: 
				ob.parcel();
				break;
			case 2:
				ob.dining();
				break;
			case 3:
				new Catalogue().display();
				break;
			default:
				throw new IllegalArgumentException("Unknown option "+parcelOrDining);	
			}
			System.out.println("press\n\t1:parcel\n\t2.dining\n\t3:catalogue\n\t0:exit");
			Scanner sc=new Scanner(System.in);
			parcelOrDining=sc.nextInt();
			check(parcelOrDining);
			}while(parcelOrDining!=0);
	}
}




