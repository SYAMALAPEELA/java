package RestaurantManagementSystem;

import java.util.Scanner;

public class HomePage //choose option for parcel and dining
{
 
	public static void main(String[] args) 
	{
		
	
			System.out.println("press 1.parcel 2.dining 3.catalogue");
			Scanner sc=new Scanner(System.in);
			int  parcelOrDining=sc.nextInt();

	}
		
	static void check(int parcelOrDining) 
	{
			Page2 ob=new Page2();
			switch(parcelOrDining)
			{
			case 1: 
				ob.parcel();
				break;
			case 2:
				ob.dining();
				break;
			case 3:
				new Catalogue().display();
				break;
			default:
				throw new IllegalArgumentException("Unknown option "+parcelOrDining);	
			}
	}
}




