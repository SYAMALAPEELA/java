package RestaurantManagementSystem;

import java.util.Scanner;

public class HomePage //choose option for parcel and dining
{
    ManualException me=new ManualException(toString());
	public static void main(String[] args) 
	{
		
	
			System.out.println("press 1.for parcel 2.for dining");
			Scanner sc=new Scanner(System.in);
			int  parcelOrDining=sc.nextInt();
			check(parcelOrDining);
		}
		
	static void check(int parcelOrDining) //throws ManualException
	{
			Page2 ob=new Page2();
			if(parcelOrDining==1 )
			{
				ob.parcel();
				
			}
			if(parcelOrDining==2) 
			{
				ob.dining();
			}
					
			
	}
}




