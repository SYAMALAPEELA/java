package RestaurantManagementSystem;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class Chicken 
{
			//Storing  and displaying List items - Set format
			Set<ItemList> chickenList=new TreeSet<ItemList>();
		
	Chicken()
	{
		
		//Make a List of Chicken items
		chickenList.add(new ItemList(301,"Chicken Tikka",1,200));
		chickenList.add(new ItemList(302,"Kabab",1,300));
		chickenList.add(new ItemList(303,"Tandoori",1,250));
		chickenList.add(new ItemList(304,"Chilli Chicken",1,350));
	}
		//display 
		void display() 
		{
			chickenList.stream().forEach(System.out::println);
		}
}
