package RestaurantManagementSystem;

public class Billing{
	Billing()
	{
		SelectItem sI=new SelectItem();
		sI.BillingItem.stream().forEach(System.out::println);
	}

}
