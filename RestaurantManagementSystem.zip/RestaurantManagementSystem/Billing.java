package RestaurantManagementSystem;

public class Billing{
	Billing()
	{
		SelectItem sI=new SelectItem();
		sI.billingItem.stream().forEach(System.out::println);
	}

}
