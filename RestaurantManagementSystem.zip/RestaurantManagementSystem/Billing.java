package RestaurantManagementSystem;

import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class Billing extends TableAvailability
{
	

	Scanner sc=new Scanner(System.in);
	int itemId,itemCount,temp=0,sum=0;
	Catalogue catalog=new Catalogue();
	SelectItem single=SelectItem.getSelectItem();
	
	Billing()
	{
		
			parcelItem();
			if(Parcel.item!=0)
			{
			for(ItemList c:catalog.mergedList )
			{
				if(c.getItemId()==itemId) 
				{
					System.out.println("enter how many packets do you want");
					itemCount=sc.nextInt();
					c.setItemCount(itemCount);
					temp=1;
					single.billingItem.add(new ItemList(c.getItemId(),c.getItemName(),c.getItemCount(),c.getItemCost()));
			
				}
		
			}
			
			if(temp==0)
			{
				throw new IllegalArgumentException(" billing Unknown option "+itemId);
			}	
			}
			}
			void parcelItem()
			{
				switch(Parcel.item)
				{
				case 0:
					single.billingItem.stream().forEach(System.out::println);
					
					System.out.format("total cost- %40d\n",total());
					System.out.println("******************************");
					for(Tables tab:t)
					{
						if(tab.getStatus().equals("RESERVED"))
						{
							tab.setStatus("ACTIVE");
							break;
						}
					}
					break;
					
				default:
				{
					System.out.println("enter Id for which food you want");
					itemId=sc.nextInt();
				}
			}
			}
			int  total()
			{
				for(ItemList c:single.billingItem )
				{
					sum=sum+c.getItemCost();
				}
				return sum;
			}
				
}

