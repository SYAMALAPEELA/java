package ConditionalState;

import java.util.Scanner;

public class SwitchAlpha {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         Scanner sc=new Scanner(System.in);
         String alphabet=sc.next();
         switch(alphabet)
         {
         case "A" , "a":System.out.println("Apple");
			break;
		case "B":
			System.out.println("Ball");
			break;
		case "b":
			System.out.println("Ball");
			break;
		case "C",
			"c":System.out.println("CAT");
			break;
			case "D",
			"d":System.out.println("Dog");
			break;
			case "E",
			"e":System.out.println("Egg");
			break;
			default:System.out.println("Not a valid option");
		sc.close();

         }
         
	}

}
