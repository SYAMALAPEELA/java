package ConditionalState;

import java.util.Scanner;

public class GreatestAmong3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter 3 numbers");
		
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c=sc.nextInt();
		if(a>=b && a>=c)
		{
			System.out.println(a + " is the greatest number");
			
		}
		else if( b>=c)
		{
			System.out.println(b + " is the greatest number");
			
		}
		else
		{
			System.out.println(c + " is the greatest number");
			
		}     //      4    3   2   3      4               3
		//largest = c > (a > b ? a : b) ? c : ((a > b) ? a : b); 
/*
 * max=num1;//max=3
		if(num2>max)//2>3
		{
			max=num2;
		}
		if(num3>max)//4>3
		{
			max=num3;//max=4
		}
		System.out.println("The Max is=:"+max);//4

 */

	}

}
