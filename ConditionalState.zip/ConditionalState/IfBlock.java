package ConditionalState;

import java.util.Scanner;

public class IfBlock {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
      System.out.println("enter your age");
      int age=sc.nextInt();
      if(age>=18)
      {
    	  System.out.println("Welcome to Vote");
      }
      else
      {
    	  System.out.println("Not Eligible to vote");
      }

	
sc.close();
	}
}
