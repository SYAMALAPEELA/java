package ConditionalState;

import java.util.Scanner;

public class EvenOrOdd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Scanner sc=new Scanner(System.in);
     System.out.println("enter a number");
    
     int num=sc.nextInt();
     if(num%2==0)
     {
    	 System.out.println(num+"is an even number");
     }
     else
     {
    	 System.out.println(num+"is an odd number");
    	 
     }
     sc.close();
	}

}
