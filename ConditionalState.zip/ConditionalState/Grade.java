package ConditionalState;

import java.util.Scanner;

public class Grade {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
	      System.out.print("Enter the Number : ");
	      int per=sc.nextInt();
	      
	      if(per >=90 )
	      {
	    	  System.out.println("Grade is : A");
	      }
	      else if(per >= 80  && per < 90 )
	      {
	    	  System.out.println("Grade is : B");
	      }
	      else if(per >= 70  && per < 80 )
	      {
	    	  System.out.println("Grade is : C");
	      }  
	      else if(per >=60   && per < 70 )
	      {
	    	  System.out.println("Grade is : D");
	      }
	      else if(per >= 50  && per < 60 )
	      {
	    	  System.out.println("Grade is : E");
	      }
	      else
	      {
	    	  System.out.println("Grade is : Fail");
	      }

	}

}
