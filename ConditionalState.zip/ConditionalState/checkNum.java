package ConditionalState;

import java.util.Scanner;

public class checkNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		      Scanner sc=new Scanner(System.in);
		      System.out.println("Enter the number");
		      int num=sc.nextInt();
		      if(num>=0)
		      {
		    	  System.out.println(num+" is a positive number");
		      }
		      else
		      {
		    	  System.out.println(num+"is a negative number");
		      }

sc.close();
	}

}
