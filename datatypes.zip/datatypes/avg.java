package datatypes;

import java.util.Scanner;

public class avg {
	public static void main(String args[]) {
		int id,m1,m2,m3,m4,m5,tot;
		double avg;
		String sName;
		Scanner s=new Scanner(System.in);
		System.out.println("enter student id");
		id=s.nextInt();
		System.out.println("enter the Student Initial");
		char initial=s.next().charAt(0);
	

		
		System.out.println("enter student name");
		sName=s.next();
		
		
		System.out.println("enter 5 subject marks");
		m1=s.nextInt();
		m2=s.nextInt();
		m3=s.nextInt();
		m4=s.nextInt();
		m5=s.nextInt();
		
		 tot=m1+m2+m3+m4+m5;
		 avg=(tot)/5;
		 double percentage=(tot*100)/500.0;
		 System.out.println("student id is :"+id);
		 System.out.println("student name is:"+initial+"."+sName);
		System.out.println("total marks:"+tot);
		System.out.println("Average is:"+avg);
		System.out.println("percentage is:"+percentage); 
		s.close();
          
	}

}
