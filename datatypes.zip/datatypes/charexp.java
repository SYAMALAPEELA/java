package datatypes;

public class charexp {
	public static void main(String args[])
	{
		char l1='a';
		char l2=65;
		char l3=0x0005;
		System.out.println(l1);
		System.out.println(l2);
		System.out.println(l3);
	}

}
