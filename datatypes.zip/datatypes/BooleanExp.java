package datatypes;
/* datatypes*/

public class BooleanExp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         boolean flag=true;
         System.out.print(flag);
	}

}
