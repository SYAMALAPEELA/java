package datatypes;

public class integerEx {
public static void main(String args[])
{
	byte b=5;
	short s=3;
	int i=333;
	long l=343;
	float f=5.5f;
	double d=5.55;
	System.out.println(b);
	System.out.println(s);
	System.out.println(i);
	System.out.println(l);
	System.out.println(f);
    System.out.println(d);


}
}
