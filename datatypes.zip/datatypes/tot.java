package datatypes;

public class tot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				int sId=23;
				String sName="gayathri";
				int m1=89,m2=90,m3=67,m4=67,m5=78;
				int total=m1+m2+m3+m4+m5;
				double percentage=(total*100)/500.0;
				System.out.println("The student Id is=:"+sId);
				System.out.println("The student Name is=:"+sName);
				System.out.println("The student total is=:"+total);
				System.out.println("The student Percentage is=:"+percentage);
				
			}

		

	}


