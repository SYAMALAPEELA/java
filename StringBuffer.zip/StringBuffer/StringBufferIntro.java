package StringBuffer;

public class StringBufferIntro {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer str1=new StringBuffer();//creating an instance with a default capacity of 16
//		StringBuffer str2=new StringBuffer();//instance of stringbuffer with specified string
//		StringBuffer str3=new StringBuffer(20);//initial capacity
//		
//		//new capacity=oldcapacity*2+2;
//		System.out.println("str1 : "+str1.capacity());
//		System.out.println("str2 : "+str2.capacity());
//		System.out.println("str3 : "+str3.capacity());
//		
//		str1.append(" Programmers.How");//16
//		System.out.println("str1 : "+str1.capacity());
//		str1.append(" is the experience");//18
//		System.out.println(str1);
//		System.out.println("str1 : "+str1.capacity());
//		str1.append(" of learning java programming");//29
//		System.out.println(str1);	
//		System.out.println("str1 : "+str1.capacity());

	}

}
