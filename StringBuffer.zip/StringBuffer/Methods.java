package StringBuffer;

public class Methods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		str2.append("Programmers.How is the experience of learning");//45
//		System.out.println("str2 count : "+str2.length());
//		System.out.println("str2 : "+str2.capacity());
//		str2.append(" java language");//
//		System.out.println("str2 count : "+str2.length());//58
//		System.out.println("str2 : "+str2.capacity());
//		
		//palindrome
		//malayalam
		//malayalam
		//12321 :12321
		
		String str = "Aditya", reverseStr = "";
	    
	    int strLength = str.length();

	    for (int i = (strLength - 1); i >=0; --i) {
	      reverseStr = reverseStr + str.charAt(i);
	    }
	    if (str.toLowerCase().equals(reverseStr.toLowerCase())) {
		      System.out.println(str + " is a Palindrome String.");
		    }
		    else {
		      System.out.println(str + " is not a Palindrome String.");
		    }	
		    
		    
		    
		    StringBuffer ref1=new StringBuffer("MALAYALAM");
		    if(ref1.equals(ref1.reverse()))
		    {
		    	System.out.println("Palindrome");
		    }
		    else
		    {
		    	System.out.println("Not a palindrome");
		    }
		    ref1.delete(0, 3);
		    System.out.println(ref1);
		    
		    ref1.ensureCapacity(200);
		    System.out.println(ref1.capacity());
		    //150 50
		    ref1.append("kghejrk gkrejhgkjre grkegkrjeg rgrekjgr jmgkrghkjreg rjgjreg m gkjreg ");
		    System.out.println(ref1.length());
		    ref1.trimToSize();
		    System.out.println(ref1.capacity());
		    System.out.println(ref1);
		    ref1.insert(0,"Welcome ");
		    System.out.println(ref1);
		    ref1.replace(7, 9, " MALA");
		    System.out.println(ref1);
		    System.out.println(ref1.substring(1, 9));
		    System.out.println(ref1.indexOf("e"));
		    System.out.println(ref1.lastIndexOf("e"));
		    System.out.println(ref1.indexOf("e",5));//from 5th to last
		    System.out.println(ref1.lastIndexOf("e",10));// from first to 10th
		    //indexOf method works in the forward direction
		    //lastIndexOf works in the backward direction

	}

}
