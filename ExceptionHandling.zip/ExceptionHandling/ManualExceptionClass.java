package ExceptionHandling;

public class ManualExceptionClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

try
{
	check(18);
	
}
catch(Exception e)
{
e.printStackTrace();	
}
	}

	static void check(int age) throws Exce
	{
		if(age<18)
		{
			throw new Exce("Invalid age for voting");
		}
		else
		{
			System.out.println("Valid age for voting");
		}
	}
}

class Exce extends Exception
{
	Exce(String str)
	{
		super(str);
	}

	}


