package String;
import java.lang.*;
public class ReplaceSecond {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String ref3="program";
		
//System.out.println(ref3.replaceFirst("r","m"))
		int a=
	System.out.println();
	}

}
