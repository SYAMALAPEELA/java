package String;

public class StringFunctions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String ref1="Java";
		String ref2="java";
				
		System.out.println(ref1.compareTo(ref2));//ref1-ref2 74-106=-32
		System.out.println(ref2.compareTo(ref1));//ref2-ref1 106-74=32
		System.out.println(ref1.compareTo("Java"));//ref1-Java 0
		
		System.out.println(ref1.compareToIgnoreCase(ref2));//ref1-ref2 74-106=-32
		System.out.println(ref2.compareToIgnoreCase(ref1));//ref2-ref1 106-74=32
		System.out.println(ref1.compareToIgnoreCase(" Java"));//ref1-Java 0
		
		System.out.println("Aakash".compareTo("Aman"));
		System.out.println("Aakash".compareToIgnoreCase("Aman"));
	
		
		String ref3="Programming";
		String ref4="Programming";
		String ref5=new String("Programming");
		String ref6=new String("Programming");
		
		System.out.println(ref3==ref4);//true
		System.out.println(ref3==ref5);//true
		System.out.println(ref4==ref5);//true
		System.out.println(ref5==ref6);//true
		
		
		/*
		 * String str="hkashf";//String constant pool
		 * String str=new String("fhjdfh");//Heap Area
		 *  
		 *  
		 *  
		 * 
		 */
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
