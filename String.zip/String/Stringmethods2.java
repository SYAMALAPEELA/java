package String;

public class Stringmethods2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Methods of String class
		String ref3="Programming";
		String ref4="Programming";
		String ref5=new String("Programming");
		String ref6=new String("Programming");
				System.out.println("Methods");
				System.out.println(ref3.contains("gram"));
				System.out.println(ref3.contains("Gram"));
				
				System.out.println(ref3.indexOf("G"));
				System.out.println(ref3.indexOf("g"));
				System.out.println(ref3.lastIndexOf("G"));
				System.out.println(ref3.lastIndexOf("g"));
				System.out.println(ref3.toUpperCase());
				System.out.println(ref3.toLowerCase());
				System.out.println(ref3.endsWith("g"));
				System.out.println(ref3.endsWith("G"));
				System.out.println(ref3.startsWith("P"));
				System.out.println(ref3.startsWith("p"));
				
				
				String ref8=new String("Java").intern();
				String ref9=new String("Java").intern();
				System.out.println(ref8==ref9);
				
				
				System.out.println(ref3.replace('m','n'));
				System.out.println(ref3.replaceAll("ming","s"));
				
				System.out.println("["+" Java Programs ".trim()+"]");

	}

}
