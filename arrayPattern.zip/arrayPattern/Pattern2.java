package arrayPattern;

public class Pattern2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char a[]= {'H','E','L','L','O'};
		for(int i=0;i<=a.length-1;i++)
		{
			for(int j=0;j<=i;j++)
			{
				System.out.print(a[j] + " ");
			}
			
			System.out.println();
		}

	}

}
