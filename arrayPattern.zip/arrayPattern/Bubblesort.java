package arrayPattern;

public class Bubblesort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Bubble Sort
		
				int ar[]= {36,45,12,3,90};
				System.out.println("Array before sorting : ");
				for(int i=0;i<ar.length;i++)
				{
					System.out.print(ar[i]+" ");
				}
				
				//bubble sort
				int c=0;
				for(int i=0;i<ar.length;i++)//iteration
				{
					for(int j=1;j<(ar.length-1);j++)//comparison
					{
						if(ar[j-1]>ar[j])
						{
							c=ar[j-1];
							ar[j-1]=ar[j];
							ar[j]=c;
						}
					}
				}
				System.out.println("Array after sorting : ");
				for(int i=0;i<ar.length;i++)
				{
					System.out.print(ar[i]+" ");
				}


	}

}
