package arrayPattern;

import java.util.Scanner;

public class BinarySearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the size of array : ");
		int n=scanner.nextInt();
		
		System.out.println("Enter "+n+" elements : ");
		
		int ar[]=new int[n];
		for(int i=0;i<n;i++)
		{
			ar[i]=scanner.nextInt();
		}
		
		System.out.println("Enter the number to be searched : ");
		int search=scanner.nextInt();
		int c=0;
		for(int i=0;i<ar.length;i++)//iteration
		{
			for(int j=1;j<(ar.length-1);j++)//comparison
			{
				if(ar[j-1]>ar[j])
				{
					c=ar[j-1];
					ar[j-1]=ar[j];
					ar[j]=c;
				}
			}
		}
		int lower_bound=0;
		int upper_bound=ar.length-1;
		int mid;
		int count=0;
		while(lower_bound<=upper_bound)
		{
			mid=(lower_bound+upper_bound)/2;
		if(ar[mid]==search)
		{
			count=1;
			break;
		}
		else if(ar[mid]>search)
		{
			upper_bound=mid-1;
			
		}
		else {
			lower_bound=mid+1;
		}
		}
		if(count==1)
		{
			System.out.print(search+"found");
		}
		else {
			System.out.print(search+"not found");
		}
		
scanner.close();
	}

}
