package arrayPattern;

import java.util.Scanner;

public class PatterExam {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		System.out.println("Enter a Number: ");
		int a,b,c;
		a=in.nextInt();
		b=in.nextInt();
		c=in.nextInt();
		if(a<=9 && b<=9 && c<=9) {
		for(int i=1;i<=a;i++) {
			for(int s=a;s>i;s--) {
				System.out.print(" ");
			}
			for(int j=1;j<=i;j++)
			{
				System.out.print(i + " ");
			}
			System.out.println();
		}
		for(int i=1;i<=b;i++) {
			for(int s=b;s>i;s--) {
				System.out.print(" ");
			}
			for(int j=1;j<=i;j++) {
				System.out.print(i+" ");
				
			}
			System.out.println();
		}
		
		for(int i=1;i<=c;i++) {
			for(int s=c;s>i;s--) {
				System.out.print(" ");
			}
			for(int j=1;j<=i;j++) {
				System.out.print(i+" ");
			}
			System.out.println();
		}
		}

	}

}
