package arrayPattern;

public class Pattern1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char a[]= {'C','O','B','O','L'};
		for(int i=a.length-1;i>=0;i--)
		{
			for(int j=0;j<=i;j++)
			{
				System.out.print(a[j] + " ");
			}
			
			System.out.println();
		}

       
       
	}

}
