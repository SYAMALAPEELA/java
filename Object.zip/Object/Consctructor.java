package Object;

public class Consctructor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Edubridge stud=new Edubridge();
		stud.show();
		Edubridge stud1=new Edubridge(12,"Nitish");
		stud1.show();
	}

}
class Edubridge
{
	int id;
	String name;
	Edubridge()
	{
		System.out.println("Welcome Students!!");
	}
	Edubridge(int id,String name)
	{
		this.id=id;
		this.name=name;
	}
	void show()
	{
		System.out.println(id+" "+name);
	}
	
	
}

	}

}
