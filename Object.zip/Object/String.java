package Object;
import java.lang.*;
public class String {

	public static void main(java.lang.String[] args) {
		// TODO Auto-generated method stub
			String ref1="Java";
			String ref2="java";
					
			System.out.println(ref1.compareTo(ref2));//ref1-ref2 74-106=-32
			System.out.println(r
	//Aakash   Aman
			//97 109
			
			
			String ref3="Programming";
			String ref4="Programming";
			String ref5=new String("Programming");
			String ref6=new String("Programming");
			
			System.out.println(ref3==ref4);//true
			System.out.println(ref3==ref5);//true
			System.out.println(ref4==ref5);//true
			System.out.println(ref5==ref6);//true
			
			
			/*
			 * String str="hkashf";//String constant pool
			 * String str=new String("fhjdfh");//Heap Area
			 *  
			 *  
			 *  
			 * 
			 */
			
			
			
			
			
			
			
			
			
			
			
			
			

		}

	}

	}

}
