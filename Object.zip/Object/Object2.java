package Object;

import java.util.Scanner;

public class Object2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter two numbers for addition : ");
		int a=scanner.nextInt();
		int b=scanner.nextInt();
		Demo demo=new Demo();
		//demo.add(a, b);
		int result = demo.add(a, b);
		System.out.println("The output of addition is "+result);
	}

}
class Demo
{
	int add(int a,int b)//parameterised user- defined method
	{
		System.out.println("Working fine");
		return a+b;
		//System.out.println("Working fine");
		//return 0;
	}
	void show()//default or non-parameterised
	{
		System.out.println("End of program!!");
	}
}


	}

}
