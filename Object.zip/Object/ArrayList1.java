package Object;
import java.util.ArrayList;
import java.lang.*;
public class ArrayList1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> al=new ArrayList<String>();//Collection with generics <>
		//type safety
		al.add("AJay");//0
		al.add("Aditya");//1
		al.add("Syamala");//2
		System.out.println(al);
		al.add(0,"Sri");
		System.out.println(al);
		al.set(1, "Adi");
		System.out.println(al);
	
		ArrayList<Book> bookList=new ArrayList<>();
		bookList.add(new Book(1234,"COmplete Reference Edition 1",1200));
		bookList.add(new Book(1233,"COmplete Reference Edition 2",1000));
		bookList.add(new Book(1123,"COmplete Reference Edition 3",800));
		bookList.add(new Book(4322,"COmplete Reference Edition 6",1300));
		bookList.add(new Book(4328,"COmplete Reference Edition 4",600));
		bookList.add(0,new Book(4354,"Let us C",210));
	
		Book b=new Book(4354,"Let us C",210);
		System.out.println(b);
		
		System.out.println(bookList);//
	}
}
class Book 
{
	int isbn;
	String bookname;
	int price;
	public Book(int isbn, String bookname, int price) {
		super();
		this.isbn = isbn;
		this.bookname = bookname;
		this.price = price;
	}
	
	public String toString()
	{
		return "("+isbn+","+bookname+","+price+")";
	}

}

	}

}
