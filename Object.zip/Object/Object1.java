package Object;

public class Object1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				// TODO Auto-generated method stub
			
//				Scanner s=new Scanner(System.in);
//				s.nextInt();
				Object1 main=new Object1();
				//ClassName referencevariablename=new ClassName();
				//new : dynamic memory allocator
				
				main.demo();
				Object1.demo1();
				User.show();//classname as a reference
				User user=new User();
				user.display();
				//location
				
			}
			public void demo()
			{
				System.out.println("Hello User");
			}
			public static void demo1()
			{
				System.out.println("Hello User");
			}
		}
	 class User
		{
			static void show()
			{
				System.out.println("Static method");
			}
			void display()
			{
				System.out.println("Non-static method");
			}
		}






		/*
		 * 
		 * Java : OOPs
		 * methods : executable block of code
		 * pre defined
		 * user defined 
		 * 
		 * static returntype methodname()
		 * {
		 * 
		 * }
		 * 
		 * 
		 * 
		 *
		 */

	}

}
