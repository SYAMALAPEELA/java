package Object;

public class ConstructorOverload {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	      new Overload();
		 new Overload(2,3);
		new Overload("s","y");
	}	
				

	}
class Overload{
	Overload(){
		System.out.println("This is constructor with 0 parameters");
	}
	Overload(int a, int b){
		System.out.println("This is a constructor with 2 int parameters,"+a+""+b);
	}
	Overload(String a,String b){
		System.out.println("This is a constructor with 2 string parameters,"
				+ a+" "+b);
	}
}


