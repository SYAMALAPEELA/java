package Object;

public class HybridInheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	

}
interface Parent{
	
}
class  Child1 implements Parent{
	
}
class Child2 implements Parent{
	
}
class Subchild extends Child1 implements Child2{
	
}
