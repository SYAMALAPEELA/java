package Object;

public class Constructorwithpara {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Learner learner=new Learner(1,"Nisha",23);
		learner.show();
		learner.disp();
		System.out.println(learner.learnerId);
		System.out.println(learner.learnerName);
		System.out.println(learner.learnerAge);
		
	}
}
class Learner
{
	int learnerId;
	String learnerName;
	int learnerAge;
	
	Learner(int id,String name,int age)
	{
		learnerId=id;
		learnerName=name;
		learnerAge=age;
	}
	void show()
	{
		System.out.println("Welcome User To Show!!\nYour details are : ");
		System.out.println("Name : "+learnerName);
		System.out.println("Id : "+learnerId);
		System.out.println("Age : "+learnerAge);
	}
	void disp()
	{
		System.out.println("Welcome User To Disp!!\nYour details are : ");
		System.out.println("Name : "+learnerName);
		System.out.println("Id : "+learnerId);
		System.out.println("Age : "+learnerAge);
	}
}

	}

}
