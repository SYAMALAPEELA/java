package Object;

public class Super {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demo3 demo3=new Demo3(1,"Shreya",26);
		demo3.display();
	}
}

class Demo1
{
	int id;	
	Demo1()
	{
		System.out.println("Welcome User!!");
	}
	Demo1(int id)
	{
		this.id=id;
	}
	void show()
	{
		System.out.println("The value for id is "+id);
	}
}
class Demo2 extends Demo1
{
	String name;
	Demo2(int id,String name){
		super(id);
		this.name=name;
	}
	void show()
	{		
		System.out.println("The value for name is "+name);
		super.show();
	}
}

class Demo3 extends Demo2
{
	int age;
	Demo3(int id,String name,int age)
	{
		super(id,name);
		this.age=age;
	}
	void show()
	{
		System.out.println("The value for age is "+age);
	}
	void display()
	{
		super.show();
		show();
	}
}

	}

}
