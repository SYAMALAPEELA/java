package Object;

public class MethodOverriding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			// TODO Auto-generated method stub
			Dummy2 dummy2=new Dummy2();
			dummy2.add(12, 23);
			Dummy12 dummy=new Dummy12();
			dummy.add(34, 46);	
			

			Dummy12 dummyRef=new Dummy2();//dynamic method dispatching or upcasting
			dummyRef.add(23, 45);
			dummyRef.sub();
			//only those methods will be called which have there existence in parent class.
			//overridden definition will be getting more priority.
		}

	}
	class Dummy12
	{
		void add(int a,int b)
		{
			System.out.println("parent"+(a+b));
		}
		void sub()
		{
			System.out.println("Hello");
		}

	}

	class Dummy2 extends Dummy12
	{
		void add(int a,int b)
		{
			System.out.println("The output of addition is ");
			System.out.println(a+b);
		}
		void sub()
		{
			System.out.println("Hello Learners");
		}


	}

