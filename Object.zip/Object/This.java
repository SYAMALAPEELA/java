package Object;

public class This {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyData myData=new MyData(1,"Nisha",27);
//		myData.show();
		
//		
//		MyData1 my=new MyData1();
//		my.initialize();
//		my.disp();
//		
//		MyData2 mydata2=new MyData2();
//		mydata2.show();
//		System.out.println("Static of class MyData2 : "+MyData2.a);
//		
//		
		MyData3 mydata3=new MyData3(1);
		mydata3.display();
		
	}

}

class MyData
{
	int id;
	String name;
	int age;
	
	MyData(int id,String name,int age)//constructor
	{
		this.id=id;
		this.name=name;
		this.age=age;
	}
	
	void show()
	{
		System.out.println(this.id+" "+this.name+" "+this.age);
	}
	
	static void disp()
	{
		MyData my=new MyData(1,"Nisha",28);
		System.out.println(my.id+" "+my.name+" "+my.age);	
	}
}
class MyData1
{
	int employeeId;
	String employeeName;
	int employeeSalary;
		
	void initialize()
	{
		this.employeeId=1;
		this.employeeName="Jatin";
		this.employeeSalary=24000;
	}
	
	void disp()
	{
		System.out.println(this.employeeId+" "+this.employeeName+" "+this.employeeSalary);
	}
}


class MyData2
{
	static int a=1;

	void show()
	{
		
		System.out.println(a);
	}

}

class MyData3
{
	int a;
	MyData3()
	{
		System.out.println("Default constructor for class MyData3");
	}
	
	MyData3(String name)
	{
		this();
		System.out.println("Hello "+name+"!");
	}
	MyData3(int a)
	{
		//refers as a call to default constructor
		this("Nisha");
		this.a=a;
	}
	void display()
	{
		System.out.println(a);
	}
	
}

	}

}
