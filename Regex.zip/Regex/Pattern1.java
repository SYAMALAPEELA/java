package Regex;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

	
		// TODO Auto-generated method stub
		public class Pattern1 {
			public static void main(String[] args) {
		
				// TODO Auto-generated method stub

				String str="admin";
				Pattern p=Pattern.compile(".{4,}n");//pattern : single character
				//. : single character digit,alphabet,special symbol
				//{4,}: quantifier : quantity 
				//.{8,15}n
				//{4}: exactly 4 characters
			
				Matcher m=p.matcher(str);
				if(m.matches())
				{
					System.out.print("Found ");
					System.out.println(m.group());
				}
				else
				{
					System.out.println("Not Found");
				}
				
			}
	}
	/* Regex stands for Regular Expression
	 *
	 * It is an api provided in java for specifying pattern for searching the data available in string.
	 * 
	 * Cap
	 * lowercase
	 * a digit
	 * a special symbol @$#%!
	 * 8-15 character
	 * 
	 * package : java.util.regex
	 * 1 interface : MatchResult interface
	 * 3 classes : Pattern,Matcher,PatternSyntaxException class
	 * 
	 * 
	 * Character Classes
	 * [abc]: character can be a,b or c but not other than this.
	 * [^abc]: 	character can be anything other than a,b or c
	 * [a-zA-Z]: character can be lowercase or uppercase both range included
	 * [a-e[u-z]]:from a to e or u to z range, character can belong
	 * [a-z&&[^n-p]]: from a-z but exclusive n-p
	 * [0-5]
[^abc][^abc][^abc][^abc]
 * [^abc]{4,}
 * 
 * 
 * Quantifier :
 * P{n} : pattern can occur exactly n times
 * P{n,m} : pattern can occur atleast n times but not more than m times
 * P{n,}: pattern can occur atleat n times or more.
 * P* : Pattern can occur 0 or more times
 * P+ : pattern can occur one or more times
 * P? : Pattern can occur once or not at all.
 * 
 * 
 * Meta character \d : \\d  at the time application, add one more \
 * .  : special character,digit, alphabet
 * \d : digits [0-9]
   \D : other than digits [^0-9]
   \w : to specify word character[a-zA-Z0-9]
   \W : non-word character [^/w]
   \b : boundary character
   \B : a non boundary character
    $ : checks for the end of string [0-9]$
    ^ : checks for the start of string ^[a-z]
   \s : checks for the escape or whitespace characters[\n \t]
   \S : checks for the non-escape or non-whitespace characters[\n \t] */

